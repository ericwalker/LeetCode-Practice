package javapractice;

import java.util.List;

public class HelloWorld {

    Solution myObject = new Solution();

    public static void main(String[] args) {
        System.out.println("Hello! World!");

        List<char> list = new ArrayList<char>();

        list.add('a');
        list.add('b');

        myObject.reverseString(s);
    }
}